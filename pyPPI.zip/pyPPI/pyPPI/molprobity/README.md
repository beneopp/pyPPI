The files in this directory are clone of molprobity binaries.


# Credits
* Vincent B. Chen, W. Bryan Arendall III, Jeffrey J. Headd, Daniel A. Keedy, Robert M. Immormino, Gary J. Kapral, Laura W. Murray, Jane S. Richardson and David C. Richardson (2010) MolProbity: all-atom structure validation for macromolecular crystallography. Acta Crystallographica D66: 12-21.
* Ian W. Davis, Andrew Leaver-Fay, Vincent B. Chen, Jeremy N. Block, Gary J. Kapral, Xueyi Wang, Laura W. Murray, W. Bryan Arendall III, Jack Snoeyink, Jane S. Richardson and David C. Richardson (2007) MolProbity: all-atom contacts and structure validation for proteins and nucleic acids. Nucleic Acids Research 35: Web Server issue, W375-W383.

# Latest version
You are encouraged to grab the latest version from the official website: http://molprobity.biochem.duke.edu/
